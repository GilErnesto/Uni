package MiniTeste_GilGuedes_125031.MiniTeste;

public class Encaminhador {
    
}
