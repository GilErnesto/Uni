# Resposta à pergunta 2-b

'''O movimento no caso:

    a-i -> O movimento não se altera e os corpos A e B, em tempos simétricos, ou seja, quando a tem um pico, B tem uma queda, e vice-versa;
    
    a-ii -> O movimento de A e B é o mesmo, mas estão desfasados, como em a-i;
    
    a-iii -> O movimento de A e B é o mesmo, mas contrariamente aos outros 2 casos, neste ambos oscilam ao mesmo tempo;
    
    '''